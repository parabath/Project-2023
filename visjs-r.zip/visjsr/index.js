const nodes = new vis.DataSet([
    { id: 1, label: 'Directory-1' },
    { id: 2, label: 'Directory-2' }
]);

const edges = new vis.DataSet([
    { from: 1, to: 2 }
]);

const container = document.getElementById('mynetwork');
const data = { nodes, edges };
const options = {};

const network = new vis.Network(container, data, options);
