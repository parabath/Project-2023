library(igraph)

# Create a data frame with node labels and their connections
node.data <- data.frame(
  from = c("a", "a", "b"),
  to = c("b", "c", "c")
)

# Create an undirected graph from the data frame
g <- graph.data.frame(
  d = node.data,
  directed = FALSE
)

# Plot the graph
plot(g, edge.label = E(g)$from)  # Display edge labels based on "from" column
